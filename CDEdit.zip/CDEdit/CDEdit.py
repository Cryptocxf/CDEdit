from charm.toolbox.pairinggroup import PairingGroup, ZR, G1, G2, GT, pair
from charm.toolbox.ABEnc import ABEnc
from datetime import datetime
from msp import MSP
import hashlib

debug = False


class CDEdit(ABEnc):
    def __init__(self, group_obj, assump_size, k, verbose=False):
        ABEnc.__init__(self)
        self.group = group_obj
        self.assump_size = assump_size  
        self.util = MSP(self.group, verbose)
        self.k = 10 # number of users
        self.index = k
        self.i = 5  
        self.j = 5  
        self.msk = {}
        self.mpk = {}
        self.pk = None
        self.sk = None
        self.deposit = 100
        self.sk_delta = None
        self.level_m_i = None #identity of modifier
        self.ID_j = None  #identity of owner
        self.I = []
        for i in range(self.k):
            self.I.append(self.group.random(ZR))

    def setup(self):
        """
        Setup algorithm
        """
	
	# pick a random element from the two source groups and pair them
        g = self.group.random(G1)
        h = self.group.random(G2)
        e_gh = pair(g, h)

	# (sk, pk)-CHET
        self.sk = self.group.random(ZR)
        self.pk = h ** self.sk

	# (sk_pts, pk_pts)-PTS
        self.sk_pts = self.group.random(ZR)
        self.pk_pts = e_gh ** self.sk_pts

	# (msk, mpk)-CP-ABE    
        a0 = self.group.random(ZR)
        a1 = self.group.random(ZR)

        b0 = self.group.random(ZR)
        b1 = self.group.random(ZR)

        d0 = self.group.random(ZR)
        g_d1 = g ** d0
        d1 = self.group.random(ZR)
        g_d2 = g ** d1
        d2 = self.group.random(ZR)
        g_d3 = g ** d2

        Z = []	# {z1,...,zk}
        G = []  # {g1,...,gk}
        H = []  # {h1,...,hk}
        GZ = []	# {g_z1,...,g_zk}
        HZ = []	# {h_z1,...,h_zk}

        for i in range(self.k):
            Z.append(self.group.random(ZR))
            G.append(self.group.random(G1))
            H.append(self.group.random(G2))
            GZ.append(g ** Z[i])
            HZ.append(h ** Z[i])

        H1 = h ** a0
        H2 = h ** a1
        T1 = e_gh ** (d0*a0 + d2)
        T2 = e_gh ** (d1*a1 + d2)
        d = d0 + d1 + d2

        # generate i modifier's identity
        self.level_m_i = 1
        for i in range(self.i):
            g_k = GZ[self.k-i-1]
            self.level_m_i *= g_k ** self.I[i]
        self.level_m_i *= g

        # generate j owner's identity
        self.ID_j = 1
        for j in range(self.j):
            h_k = HZ[self.k-j-1]
            self.ID_j *= h_k ** self.I[j]
        self.ID_j *= h

        self.msk = {'a0':a0, 'a1':a1, 'b0':b0, 'b1':b1, 'd0':d0, 'd1':d1, 'd2':d2, 'g_d1':g_d1, 'g_d2':g_d2, 'g_d3':g_d3, 'Z':Z}
        self.mpk = {'g':g, 'h':h, 'H1':H1, 'H2':H2, 'T1':T1, 'T2':T2, 'GZ':GZ, 'HZ':HZ}
        
        return self.sk, self.pk, self.msk, self.mpk, self.sk_pts, self.pk_pts

    def tkgen(self, mpk, sk_pts, pk_pts, n_time, req_tk):
        """
        Tkgen algorithm
        """

        g = mpk['g']
        h = mpk['h']
        sk_pts = self.sk_pts
        pk_pts = self.pk_pts
        deposit = self.deposit
        sigma_pts = sk_pts + self.group.hash(str(pk_pts)+str(req_tk)+str(deposit))
        self.pri_tk = [req_tk, sigma_pts, datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')]

        return self.pri_tk

    def keygen(self, sk, pk, msk, mpk, attr_list):
        """
        Keygen algorithm
        """

        msk = self.msk
        mpk = self.mpk
        sk = self.sk
        pk = self.pk
        g = mpk['g']
        h = mpk['h']
        x = sk
        d = msk['d0'] + msk['d1'] + msk['d2']
        R = self.group.random(ZR)
        r1 = self.group.random(ZR)
        r2 = self.group.random(ZR)
        r = r1 + r2
        h_b1_r1 = h ** (msk['b0']*r1)
        h_b2_r2 = h ** (msk['b1']*r2)
        h_r1_r2 = h ** (r1+r2)
        g_r = g ** r
        g_R = g ** R
        sk0 = {'h_b1_r1':h_b1_r1, 'h_b2_r2':h_b2_r2, 'h_r1_r2':h_r1_r2,'g_r':g_r, 'g_R':g_R}
        SK = {} # SK = {[sk_y_1, sk_y_2]} sk_y_t
        sk_prime = []  
	
        for attr in attr_list:
            sigma_y = self.group.random(ZR)
            key = []
            for t in range(self.assump_size):
                input_for_hash1 = attr + str(0) + str(t)
                input_for_hash2 = attr + str(1) + str(t)
                input_for_hash3 = attr + str(2) + str(t)
                a_t = 'a' + str(t)
                sk_y_t = self.group.hash(input_for_hash1, G1) ** (msk['b0']*r1/msk[a_t])  * self.group.hash(input_for_hash2, G1) ** (msk['b1']*r2/msk[a_t]) * self.group.hash(input_for_hash3, G1) ** ((r1+r2)/(msk[a_t])) * g ** (sigma_y/(msk[a_t]))
                key.append(sk_y_t)
            key.append(g ** (-sigma_y))
            SK[attr] = key

        sigma_prime = self.group.random(ZR)
        for t in range(self.assump_size):
            input_for_hash1 = "010" + str(t)
            input_for_hash2 = "011" + str(t)
            input_for_hash3 = "012" + str(t)
            a_t = 'a' + str(t)
            d_t = 'd' + str(t)
            sk_t = g ** msk[d_t] * self.group.hash(input_for_hash1, G1) ** (msk['b0']*r1/msk[a_t])  * self.group.hash(input_for_hash2, G1) ** (msk['b1']*r2/msk[a_t]) * self.group.hash(input_for_hash3, G1) ** ((r1+r2)/(msk[a_t])) * g ** (sigma_prime/(msk[a_t]))
            sk_prime.append(sk_t)
        sk_prime.append(g ** msk['d2'] * g ** (-sigma_prime))	

        
        sk1 = g ** d * self.level_m_i ** ( r) * g ** (R)
        sk2 = [None] * ((self.i-1)*2)
        for i in range(self.i-1):
            g_k = mpk['GZ'][self.i-1-i]
            sk2[i] = g_k ** (r)
        ssk = {'sk0':sk0, 'sk_y_t':SK, 'sk_prime':sk_prime, 'sk1':sk1, 'sk2':sk2}
        self.sk_delta = {'x':x, 'ssk':ssk, 'attr_list':attr_list}
        return self.sk_delta   
    
    def hash(self, m, pk, msk, mpk, policy_str):
        """
        Hash algorithm
        """

        msk = self.msk
        mpk = self.mpk
        pk = self.pk
        h = mpk['h']
        g = mpk['g']
        policy = self.util.createPolicy(policy_str)
        mono_span_prog = self.util.convert_policy_to_msp(policy)
        num_cols = self.util.len_longest_row

        # step 1
        r = self.group.random(ZR)
        p = pk ** r
	
        # step 2
        R = self.group.random(ZR)  
        sha256 = hashlib.new('sha256')
        sha256.update(self.group.serialize(R))
        hd = sha256.hexdigest() 
        seed = str(hd)
        etd = self.group.hash(seed, ZR)  #ephemeral tradoor
        h_prime = h ** etd

        # step 3
        m = self.group.random(ZR)
        ch = p * h_prime ** m # chameleon hash value
	
        # step 4
        s = []
        sum = 0	# sum = s1 + s2
        for i in range(self.assump_size):
            rand = self.group.random(ZR)
            s.append(rand)
            sum += rand
        _sk = sum
        _vk = self.ID_j ** sum

        # step 5
        ct0 = []
        H1 = mpk['H1']
        H2 = mpk['H2']
        ct0.append(H1**s[0])
        ct0.append(H2**s[1])
        ct0.append(h**(sum))
        hash_table = []
        for j in range(num_cols):
            x = []
            input_for_hash1 = '0' + str(j + 1)
            for l in range(self.assump_size + 1):
                y = []
                input_for_hash2 = input_for_hash1 + str(l)
                for t in range(self.assump_size):
                    input_for_hash3 = input_for_hash2 + str(t)
                    hashed_value = self.group.hash(input_for_hash3, G1)
                    y.append(hashed_value)
                x.append(y)
            hash_table.append(x)
	
        C = {}
        for attr, row in mono_span_prog.items():
            ct = []
            attr_stripped = self.util.strip_index(attr) 
            for l in range(self.assump_size + 1):
                prod = 1
                cols = len(row)
                for t in range(self.assump_size):
                    input_for_hash = attr_stripped + str(l) + str(t)
                    prod1 = self.group.hash(input_for_hash, G1)
                    for j in range(cols):
                        prod1 *= (hash_table[j][l][t] ** row[j])
                    prod *= (prod1 ** s[t])
                ct.append(prod)
            C[attr] = ct
	
        msg = mpk['T1'] ** s[0] * mpk['T2'] ** s[1]
        sha256 = hashlib.new('sha256')
        sha256.update(self.group.serialize(msg))
        hd = sha256.hexdigest() 
        seed = str(hd)
        _ct = r * self.group.hash(seed, ZR) 		
        d = msk['d0'] + msk['d1'] + msk['d2']     
        cpp = pair(g,h**d) ** _sk
        seed = str(cpp)
        _ctp = R * self.group.hash(seed, ZR) 		
        _ct2p = _vk
        _ct3p = self.ID_j ** (sum)
        _ct4p = _vk ** (sum)
        _C = [ct0, C, _ct, _ctp, _ct2p, _ct3p, policy, _ct4p]
        
        # step 6
        c = h ** (_sk + etd)
        esk = self.group.random(ZR)
        epk = pair(g, _vk) ** esk
        sigma = esk + _sk*self.group.hash(str(epk)+str(c))

        # step 7
        return m, p, h_prime, ch, _C, c, epk, sigma  

    def verify_m(self, pri_tk, pk_pts):  #Is the token correct?
        """
        Verify_m algorithm
        """

        req_tk = pri_tk[0]
        sigma_pts = pri_tk[1]
        deposit = self.deposit

        if pri_tk[0][0] == "T_1tk":
            pri_tk.append('T_1m')
        elif pri_tk[0][0] == "T_ntk":
            pri_tk.append('T_nm')
        elif pri_tk[0][0] == "B_1tk":
            pri_tk.append('B_1m')
        elif pri_tk[0][0] == "B_ntk":
            pri_tk.append('B_nm')

        base = pair(self.mpk['g'],self.mpk['h'])
        base_sigma_pts = pk_pts * base ** self.group.hash(str(pk_pts)+str(req_tk)+str(deposit))

        if (base ** sigma_pts == base_sigma_pts):
            return True
        else:
            return False

    def verify(self, m, p, h_prime, ch, C, c, epk, sigma):  
        """
        Verify algorithm
        """

        vk = C[4]  # get vk
        vk_s = C[7] # get vk_s
        ch_prime = p * h_prime ** m

        base = pair(self.mpk['g'], vk)
        base_sigma_prime = epk * pair(self.mpk['g'], vk_s) ** self.group.hash(str(epk)+str(c))

        if (ch == ch_prime and base**sigma == base_sigma_prime):
            return True
        else:
            return False

    def adapt(self, sk_delta, m, m_prime, p, h_prime, ch, C, c, epk, sigma, level_m_i, policy_str):
        """
        Adapt algorithm
        """

        m_prime = self.group.random(ZR)
        _m = self.group.random(ZR)
        g = self.mpk['g']
        h = self.mpk['h']
        d = self.msk['d0'] + self.msk['d1'] + self.msk['d2']
        mpk = self.mpk
        msk = self.msk
        sk_delta = self.sk_delta
        sk_prime = self.sk_delta['ssk']['sk_prime']
        level_m__i = self.level_m_i

        policy = self.util.createPolicy(policy_str)
        mono_span_prog = self.util.convert_policy_to_msp(policy)
        num_cols = self.util.len_longest_row

        # step 2.(b)
        ctp = C[3]
        pair1 = pair(sk_delta['ssk']['sk1'], C[0][2])	# C[0][2] = ct0,3
        pair2 = pair(sk_delta['ssk']['sk0']['g_r'], C[4])	# C[4] = ct2p
        pair3 = pair(sk_delta['ssk']['sk0']['g_R'], C[0][2]) # C[0][3] = mpk['h_beta_alpha'] ** sum
        cpp = pair1 / (pair2 * pair3)

        seed = str(cpp)
        R = ctp / self.group.hash(seed, ZR)

        # step 3
        nodes = self.util.prune(C[6], self.sk_delta['attr_list']) # C[6] = ctxt['policy'] get ciphertext policy
        if not nodes:
            print ("Policy is not satisfied.")
            return None

        sk0_tmp = []
        sk0_tmp.append(sk_delta['ssk']['sk0']['h_b1_r1'])
        sk0_tmp.append(sk_delta['ssk']['sk0']['h_b2_r2'])
        sk0_tmp.append(sk_delta['ssk']['sk0']['h_r1_r2'])

        prod1_GT = 1   # num
        prod2_GT = 1   # den
        for i in range(self.assump_size + 1):	
            prod_H = 1
            prod_G = 1
            for node in nodes:
                attr = node.getAttributeAndIndex()
                attr_stripped = self.util.strip_index(attr)  
                prod_H *= sk_delta['ssk']['sk_y_t'][attr_stripped][i]
                prod_G *= C[1][attr][i]			     # C[1] = _C
            prod1_GT *= pair(sk_prime[i]*prod_H, C[0][i])
            prod2_GT *= pair(prod_G, sk0_tmp[i])
        Cp = -(prod2_GT / prod1_GT)

        sha256 = hashlib.new('sha256')
        sha256.update(self.group.serialize(Cp))
        x = sha256.hexdigest()
        seed = str(x)
        r_tmp = C[2] / self.group.hash(seed, ZR)	# C[2] = _ct

	# step 
        s_prime = []
        sum_prime = 0	# sum = s1 + s2
        for i in range(self.assump_size):
            rand = self.group.random(ZR)
            s_prime.append(rand)
            sum_prime += rand
        _sk_prime = sum_prime
        _vk_prime = self.ID_j ** sum_prime 

        #step 4  
        sha256 = hashlib.new('sha256')
        sha256.update(self.group.serialize(R))
        hd = sha256.hexdigest() 
        seed = str(hd)
        etd = self.group.hash(seed, ZR)
        r_prime = r_tmp + (m - m_prime)*etd/self.sk
        p_prime = self.pk ** r_prime   
     
        # step 5 
        ct0 = []
        H1 = mpk['H1']
        H2 = mpk['H2']
        ct0.append(H1**s_prime[0])
        ct0.append(H2**s_prime[1])
        ct0.append(h**(sum_prime))

        hash_table = []
        for j in range(num_cols):
            x = []
            input_for_hash1 = '0' + str(j + 1)
            for l in range(self.assump_size + 1):
                y = []
                input_for_hash2 = input_for_hash1 + str(l)
                for t in range(self.assump_size):
                    input_for_hash3 = input_for_hash2 + str(t)
                    hashed_value = self.group.hash(input_for_hash3, G1)
                    y.append(hashed_value)
                x.append(y)
            hash_table.append(x)
	
        # compute C = ct_u_l
        C = {}
        for attr, row in mono_span_prog.items():
            ct = []
            attr_stripped = self.util.strip_index(attr)  
            for l in range(self.assump_size + 1):
                prod = 1
                cols = len(row)
                for t in range(self.assump_size):
                    input_for_hash = attr_stripped + str(l) + str(t)
                    prod1 = self.group.hash(input_for_hash, G1)
                    for j in range(cols):
                        prod1 *= (hash_table[j][l][t] ** row[j])
                    prod *= (prod1 ** s_prime[t])
                ct.append(prod)
            C[attr] = ct
	
        # step 6
        sha256 = hashlib.new('sha256')
        msg = mpk['T1'] ** s_prime[0] * mpk['T2'] ** s_prime[1]
        sha256.update(self.group.serialize(msg))
        hd = sha256.hexdigest() 
        seed = str(hd)
        _ct = r_prime * self.group.hash(seed, ZR) 	
        d = msk['d0'] + msk['d1'] + msk['d2']
        
        cpp = pair(g,h**d) ** _sk_prime
        seed = str(cpp)
        _ctp = etd * self.group.hash(seed, ZR) 		
        _ct2p = _vk_prime
        _ct3p = self.ID_j ** (sum_prime)
        _ct4p = _vk_prime ** (sum_prime)
        _C = [ct0, C, _ct, _ctp, _ct2p, _ct3p, policy, _ct4p]
        C_prime = _C

        c_prime = h ** (_sk_prime + etd)
        esk_prime = self.group.random(ZR)
        epk_prime = pair(g, _vk_prime) ** esk_prime
        sigma_prime = esk_prime + _sk_prime*self.group.hash(str(epk_prime)+str(c_prime))

        return m_prime, p_prime, h_prime, ch, C_prime, c_prime, epk_prime, sigma_prime 


    def audit(self, m, p, h_prime, ch, C, c, epk, sigma, m_prime, p_prime, C_prime, c_prime, epk_prime, sigma_prime):
        """
        Audit algorithm
        """

        verify_1, verify_2, verify_3 = 0, 0, 0
        h = self.mpk['h']
        g = self.mpk['g']
        vk = C[4]
        vk_prime = C_prime[4]

        # step 1
        ch0 = p * h_prime ** m
        ch1 = p_prime * h_prime ** m_prime
        if (ch == ch0 and ch == ch1):
            verify_1 = 1
        
        # step 2
        vk_s = C[7]
        vk_s_prime = C_prime[7]
        base = pair(g, vk)
        base_prime = pair(g, vk_prime)
        base_sigma0 = epk * pair(g, vk_s) ** self.group.hash(str(epk)+str(c))
        base_sigma1 = epk_prime * pair(g, vk_s_prime) ** self.group.hash(str(epk_prime)+str(c_prime))
        if (base**sigma == base_sigma0 and base_prime**sigma_prime == base_sigma1):
            verify_2 = 1
        
        # step 3
        delta_sk = c_prime / c
        ct_0_3 = C[0][2]
        ct_0_3_prime = C_prime[0][2]
        if (ct_0_3_prime == ct_0_3 * delta_sk):
            verify_3 = 1
        if verify_1 == verify_2 == verify_3:
            return True
        else:
            return False












