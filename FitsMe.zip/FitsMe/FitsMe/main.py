from charm.toolbox.pairinggroup import PairingGroup, GT
from FitsMe import FitsMe
import time


def main():
    n_time = 1  # n-times modifications
    d = 10   # number of attributes
    type_m = 'T_1tk'  # type_m = ['T_1tk', 'T_ntk',' B_1tk', 'B_ntk']
    level_m= ['T_1m','T_nm','B_1m','B_nm']  # level of privilege
    index = "B100-T12"  # index of transactions or block (e.g. trasnaction NO.T12 of block NO.B100)
    m = None
    B,Chain = [],[]
    ID_j = "Owner-101" # Identify ID of the requester 
    trial = 100
    attr_list = ['RED', 'BLUE','GREEN','YEELOW']
    policy_str = '((RED and GREEN) and (BLUE OR YELLOW))'
    Setup_time = False
    TKGen_time = False
    KeyGen_time = False
    Hash_time = False
    Verify_m_time = False
    Verify_time = False
    Adapt_time = False
    Audit_time = False

    pairing_group = PairingGroup('MNT224')  
    fitsme = FitsMe(pairing_group, 2, 10) # (tree with depth of 10) AC17 CP-ABE under DLIN (2-linear)

    (sk, pk, msk, mpk, sk_pts, pk_pts) = fitsme.setup()     # setup()

    if n_time == 1 and type_m == 'T_1tk':
        req_tk = [type_m, ID_j, n_time,index]
    elif n_time == 1 and type_m == 'B_1tk':
        req_tk = [type_m, ID_j, n_time,index]
    elif n_time > 1 and type_m == 'T_ntk':
        req_tk = [type_m, ID_j, n_time,index]
    elif n_time > 1 and type_m == 'B_ntk':
        req_tk = [type_m, ID_j, n_time,index]

    pri_tk = fitsme.tkgen(mpk, sk_pts, pk_pts, n_time, req_tk)   # tkgen()
    sk_delta = fitsme.keygen(sk, pk, msk, mpk, attr_list)     # keygen()
    m_prime = None 
    if (fitsme.verify_m(pri_tk, pk_pts) == True):# verify_m()
        print ("Token successful verification.")
        print('pri_tk =', pri_tk) # privilege token
        if pri_tk[3] == "T_1m" or pri_tk[3] == "T_nm":
            while n_time >= 1:
                (m, p, h_prime, ch, C, c, epk, sigma) = fitsme.hash(m, pk, msk, mpk, policy_str)  # hash()
                if (fitsme.verify(m, p, h_prime, ch, C, c, epk, sigma) == True):  # verify()
                    print ("1-Transaction Verification passed.")
                else:
                    print ("Failed.")
                level_m_i = "T_1m-12"
                (m_prime, p_prime, h, ch, C_prime, c_prime, epk_prime, sigma_prime) = fitsme.adapt(sk_delta, m, m_prime, p, h_prime, ch, C, c, epk, sigma, level_m_i, policy_str)   # adapt()
                if (fitsme.verify(m_prime, p_prime, h_prime, ch, C_prime, c_prime, epk_prime, sigma_prime) == True):
                    print ("2-Verification passed.")
                else:
                    print ("Failed.")
                if (fitsme.audit(m, p, h, ch, C, c, epk, sigma, m_prime, p_prime, C_prime, c_prime, epk_prime, sigma_prime) == True):  # audit()
                    print ("3-Audit passed.")
                else:
                    print ('Error editor: ',level_m_i)
                n_time=n_time-1

        # Chain = [B0, B1, ..., Bn],B = [PreH, m, p, ch,h]
        elif pri_tk[3] == "B_1m" or pri_tk[3] == "B_nm":
            u,v = 0,1  
            Nonce,PreH = None,None
            while u<5:  # generate a chain of length 5
                print("Block:",u)
                B.append(PreH)
                (m, p, h_prime, ch, C, c, epk, sigma) = fitsme.hash(m, pk, msk, mpk, policy_str)
                B.append(m)
                B.append(p)  #Nonce
                B.append(ch)
                B.append(h_prime)
                if (fitsme.verify(m, p, h_prime, ch, C, c, epk, sigma) == True):  # verify()
                    print ("1-Successful Verification.")
                else:
                    print ("Verification Failed.")
                print(B,"\n")
                Chain.append(B) 
                B = []
                PreH = ch
                u=u+1
            for i in range(v,v+n_time): # modify the (v, v+n_time)-th blocks
                m = Chain[i][1]
                p = Chain[i][2]
                ch = Chain[i][0]
                level_m_i = "B_1m-10"
                (m_prime, p_prime, h, ch, C_prime, c_prime, epk_prime, sigma_prime) = fitsme.adapt(sk_delta, m, m_prime, p, h_prime, ch, C, c, epk, sigma, level_m_i, policy_str)   # adapt()
                Chain[i][1] = m_prime
                Chain[i][2] = p_prime
                print("Block*:",i)
                print(Chain[i],"\n")
                i = i + 1         
    else:
        print ("Token verification failed.")

    
#---------------------------------RUNNING TIMES OF SETUP() ALGORITHM------------------------------------------

    if Setup_time:
        f = open('result_setup.txt', 'w+')  
        f.write("(Ave-time,")  
        print("--------Setup Phase--------")
        T,Temp,start,end = 0,0,0,0
        for i in range(trial):
            start = time.time()  
            (sk, pk, msk, mpk, sk_pts, pk_pts) = fitsme.setup()
            end = time.time() 
            Temp=end - start  
            T+=Temp
        T=T/trial
        print('Ave-time:',T)
        f.write(str(T) + ")\n")
        f.close()

#---------------------------------RUNNING TIME OF TKGEN() ALGORITHM------------------------------------------

    if TKGen_time:
        f = open('result_tkgen.txt', 'w+')
        print("--------TKGen Phase--------")
        f.write("(" + str(d) + ",")
        T,Temp,start,end = 0,0,0,0
        for i in range(trial):
            start = time.time()
            pri_tk = fitsme.tkgen(mpk, sk_pts, pk_pts, n_time, req_tk)
            end = time.time()
            Temp = end - start
            T += Temp
        T = T/trial
        print('Ave-time:',T)
        f.write(str(T) + ")\n")
        f.close()

#---------------------------------RUNNING TIME OF KEYGEN() ALGORITHM-------------------------------------------

    if KeyGen_time:
        d=10  # number of attributes  
        test = 100
        print ("--------KeyGen Phase--------")       
        f = open('result_keygen.txt', 'w+')
        while d <= test:
            f.write("(" + str(d) + ",")
            T,Temp,start,end = 0,0,0,0
            attr_list = []
            for i in range(d):
                attr_list.append(str(i))
            for i in range(trial):
                start = time.time()
                sk_delta = fitsme.keygen(sk, pk, msk, mpk, attr_list)
                end = time.time()
                Temp = end - start
                T += Temp
                #print(T)
            T = T / trial
            print('Ave-time:',d,T)
            f.write(str(T) + ")\n")
            d += 10
        f.close()

#---------------------------------RUNNING TIME OF HASH() ALGORITHM-------------------------------------------

    if Hash_time:
        d=10     
        test = 100
        print ("--------Hash Phase--------")
        f = open('result_hash.txt', 'w+')
        while d <= test:
            f.write("(" + str(d) + ",")
            T,Temp,start,end = 0,0,0,0
            attr_list = []
            for i in range(2*d+1):
                attr_list.append(str(i))
            sk_delta = fitsme.keygen(sk, pk, msk, mpk, attr_list)  
            policy_str=""
            for j in range(d):
                if j!=d-1:
                    policy_str = policy_str + "( "+str(2*j) + " and "+ str(2*j+1)+" )" + " OR "
                else:
                    policy_str = policy_str + "( " + str(2 * j) + " and " + str(2 * j + 1) + " )"
            for i in range(trial):
                m = None
                start = time.time()
                (m, p, h_prime, ch, C, c, epk, sigma) = fitsme.hash(m, pk, msk, mpk, policy_str)
                end = time.time()
                Temp = end - start
                T += Temp
            T = T / trial
            print('Ave-time:',d,T)
            f.write(str(T) + ")\n")
            d += 10
        f.close()

#---------------------------------RUNNING TIME OF VERIFY_M() ALGORITHM-------------------------------------------

    if Verify_m_time:
        d=10    
        test = 100
        print ("--------Verify_m Phase--------")
        f = open('result_verify_m.txt', 'w+')
        while d <= NN:
            f.write("(" + str(d) + ",")
            T,Temp,start,end = 0,0,0,0
            attr_list = []
            for i in range(2*d+1):
                attr_list.append(str(i))
            sk_delta = fitsme.keygen(sk, pk, msk, mpk, attr_list)
            policy_str=""
            for j in range(d):
                if j!=d-1:
                    policy_str = policy_str + "( "+str(2*j) + " and "+ str(2*j+1)+" )" + " OR "
                else:
                    policy_str = policy_str + "( " + str(2 * j) + " and " + str(2 * j + 1) + " )"        
            (m, p, h_prime, ch, C, c, epk, sigma) = fitsme.hash(m, pk, msk, mpk, policy_str)
            pri_tk = fitsme.tkgen(mpk, sk_pts, pk_pts, n_time, req_tk)           
            for i in range(trial):
                m_prime = None 
                ID_i = None
                start = time.time()
                fitsme.verify_m(pri_tk, pk_pts)
                end = time.time()
                Temp = end - start
                T += Temp
            T = T / trial
            print('Ave-time:',d,T)
            f.write(str(T) + ")\n")
            d += 10
        f.close()

#---------------------------------RUNNING TIME OF VERIFY() ALGORITHM-------------------------------------------

    if Verify_time:
        d=10      
        test = 100
        print ("--------Verify Phase--------")
        f = open('result_verify.txt', 'w+')
        while d <= test:
            f.write("(" + str(d) + ",")
            T,Temp,start,end = 0,0,0,0
            attr_list = []
            for i in range(2*d+1):
                attr_list.append(str(i))
            sk_delta = fitsme.keygen(sk, pk, msk, mpk, attr_list)
            policy_str=""
            for j in range(d):
                if j!=d-1:
                    policy_str = policy_str + "( "+str(2*j) + " and "+ str(2*j+1)+" )" + " OR "
                else:
                    policy_str = policy_str + "( " + str(2 * j) + " and " + str(2 * j + 1) + " )"        
            (m, p, h_prime, ch, C, c, epk, sigma) = fitsme.hash(m, pk, msk, mpk, policy_str)          
            for i in range(trial):
                m_prime = None 
                ID_i = None
                start = time.time()
                fitsme.verify(m, p, h_prime, ch, C, c, epk, sigma)
                end = time.time()
                Temp = end - start
                T += Temp
            T = T / trial
            print('Ave-time:',d,T)
            f.write(str(T) + ")\n")
            d += 10
        f.close()

#---------------------------------RUNNING TIME OF ADAPT() ALGORITHM-------------------------------------------

    if Adapt_time:
        d=10     
        test = 100
        print ("--------Adapt Phase--------")
        f = open('result_adapt.txt', 'w+')
        while d <= test:
            f.write("(" + str(d) + ",")
            T,Temp,start,end = 0,0,0,0
            attr_list = []
            for i in range(2*d+1):
                attr_list.append(str(i))
            sk_delta = fitsme.keygen(sk, pk, msk, mpk, attr_list)
            policy_str=""
            for j in range(d):
                if j!=d-1:
                    policy_str = policy_str + "( "+str(2*j) + " and "+ str(2*j+1)+" )" + " OR "
                else:
                    policy_str = policy_str + "( " + str(2 * j) + " and " + str(2 * j + 1) + " )"
            (m, p, h_prime, ch, C, c, epk, sigma) = fitsme.hash(m, pk, msk, mpk, policy_str)    
            for i in range(trial):
                m_prime = None 
                level_m_i = None
                start = time.time()
                (m_prime, p_prime, h, ch, C_prime, c_prime, epk_prime, sigma_prime) = fitsme.adapt(sk_delta, m, m_prime, p, h, ch, C, c, epk, sigma, level_m_i, policy_str)
                end = time.time()
                Temp = end - start
                T += Temp
            T = T / trial
            print('Ave-time:',d,T)
            f.write(str(T) + ")\n")
            d += 10
        f.close()
    
#---------------------------------RUNNING TIME OF AUDIT() ALGORITHM------------------------------------------- 
  
    if Audit_time:
        d=10    
        test = 100
        print ("--------Audit Phase--------")
        f = open('result_audit.txt', 'w+')
        while d <= test:
            f.write("(" + str(d) + ",")
            T,Temp,start,end = 0,0,0,0
            attr_list = []
            for i in range(2*d+1):
                attr_list.append(str(i))
            sk_delta = fitsme.keygen(sk, pk, msk, mpk, attr_list)
            policy_str=""
            for j in range(d):
                if j!=d-1:
                    policy_str = policy_str + "( "+str(2*j) + " and "+ str(2*j+1)+" )" + " OR "
                else:
                    policy_str = policy_str + "( " + str(2 * j) + " and " + str(2 * j + 1) + " )"
            
            (m, p, h_prime, ch, C, c, epk, sigma) = fitsme.hash(m, pk, msk, mpk, policy_str)
            m_prime = None 
            level_m_i = None
            (m_prime, p_prime, h, ch, C_prime, c_prime, epk_prime, sigma_prime) = fitsme.adapt(sk_delta, m, m_prime, p, h, ch, C, c, epk, sigma, level_m_i, policy_str)
            for i in range(trial):
                start = time.time()
                fitsme.audit(m, p, h_prime, ch, C, c, epk, sigma, m_prime, p_prime, C_prime, c_prime, epk_prime, sigma_prime)
                end = time.time()
                Temp = end - start
                T += Temp
            T = T / trial
            print('Ave-time:',d,T)
            f.write(str(T) + ")\n")
            d += 10
        f.close()

if __name__ == "__main__":
    debug = True
    main()
